from airflow import DAG
from airflow.operators.python import PythonOperator  # type: ignore
from datetime import datetime
import pandas as pd
import os

dag_path = os.path.dirname(__file__)

def extract():
    csv_path = os.path.join('/root/airflow/django2/business_intelligence/data', 'Walmart_Sales_Cleaned_Final.csv')
    print("Checking path:", csv_path)
    print("File exists:", os.path.exists(csv_path))
    df = pd.read_csv(csv_path, sep=';')
    df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
    print("Null dates after parsing:", df['Date'].isna().sum())
    df.to_csv('/tmp/extracted_walmart.csv', index=False)
    print("✅ Extract complete")

def transform():
    df = pd.read_csv('/tmp/extracted_walmart.csv')
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df['Month'] = df['Date'].dt.month
    df['Month_Name'] = df['Date'].dt.strftime('%B')

    print("Kolom tersedia:", df.columns.tolist())

    # Ganti dengan nama kolom yang benar sesuai file asli
    revenue_col = 'Total Revenue' if 'Total Revenue' in df.columns else 'Total_Revenue'

    result = df.groupby(['City', 'Store Type', 'Month', 'Month_Name'])[revenue_col].sum().reset_index()
    result.to_csv('/tmp/transformed_walmart.csv', index=False)
    print("✅ Transform complete")

def load():
    df = pd.read_csv('/tmp/transformed_walmart.csv')
    output_path = os.path.join('/root/airflow/django2/business_intelligence/data', 'Walmart_OLAP.csv')
    df.to_csv(output_path, index=False)
    print("✅ Load complete to:", output_path)

with DAG(
    dag_id='walmart_etl_olap',
    start_date=datetime(2025, 6, 12),
    schedule='@daily',  # ✅ sudah benar!
    catchup=False,
    tags=['walmart', 'etl']
) as dag:

    t1 = PythonOperator(
        task_id='extract',
        python_callable=extract
    )

    t2 = PythonOperator(
        task_id='transform',
        python_callable=transform
    )

    t3 = PythonOperator(
        task_id='load',
        python_callable=load
    )

    t1 >> t2 >> t3
