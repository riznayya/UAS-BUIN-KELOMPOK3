from django.apps import AppConfig


class BusinessIntelligenceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'business_intelligence'
